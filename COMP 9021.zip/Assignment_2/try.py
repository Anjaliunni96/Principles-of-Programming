

# IMPORT ANY REQUIRED MODULE



def display_cord(gate , walls , inac , ac , cpoint):
        if(gate==0):
            print("The maze has no gate.")
        elif(gate==1):
            print("The maze has a single gate.")
        elif(gate>1):    
            print("The maze has",gate,"gates.")
            
        if(walls==0):
            print("The maze has no wall.")
        elif(walls==1):
            print("The maze has walls that are all connected.")
        elif(walls>1):    
            print("The maze has",walls,"sets of walls that are all connected.")
            
        if(inac==0):
            print("The maze has no inaccessible inner point.")
        elif(inac==1):
            print("The maze has a unique inaccessible inner point.")
        elif(inac>1):    
            print("The maze has",inac,"inaccessible inner points.")     
            
        if(ac==0):
            print("The maze has no accessible area.")
        elif(ac==1):
            print("The maze has a unique accessible area.")
        elif(ac>1):    
            print("The maze has",ac,"accessible areas.")    
            

        if(cpoint==0):
            print("The maze has no accessible cul-de-sac.")
        elif(cpoint==1):
            print("The maze has accessible cul-de-sacs that are all connected.")
        elif(cpoint>1):    
            print("The maze has",cpoint,"sets of accessible cul-de-sacs that are all connected.")


class MazeError(Exception):
    def __init__(self, message):
        self.message = message


class Maze:
    def __init__(self, filename):

### READING FILE  AND VALIDATING INPUT

        list1=[]
        temp=[]
        with open(filename, 'r') as file:
            file = file.read().split("\n")
            #print(file)
            for line in file:
                if line != '[]':
                    temp=[]
                    for j in line:
                        if j == '0'or j== '1' or j == '2'or j == '3':
                            temp.append(j)
                            #print(j)
                        elif j==' ':
                            continue
                        elif j=='\n':
                            continue
                        else:
                            raise MazeError('Incorrect input.')
                    if temp != []:
                        list1.append(temp)
            #print("------")

            self.checkl=[]
            #print(list1)
            self.checkl=[i[:] for i in list1]
            #print("List 2 = ",self.checkl)

            rows=len(self.checkl)
            cols=len(list(zip(*self.checkl)))

            #print("rows = ",rows)
            #print("cols = ",cols)

### CHECK CONDITIONS FOR MATRIX

            if rows >= 2 and rows <= 41 and cols >=2 and cols <=31:
                #print("valid input")
                for x in range(0,len(self.checkl)):
                    if len(self.checkl[x])!=cols:
                        raise MazeError('Incorrect input.')
                for x in self.checkl[-1]:
                    if x[-1]!='0' and x[-1]!='1':
                        raise MazeError('Input does not represent a maze.')
                        break
                for x in range(0,rows):
                    if self.checkl[x][cols-1]=='0' or self.checkl[x][cols-1]=='2':
                        pass
                    else:
                        raise MazeError('Input does not represent a maze.')
            else:
                raise MazeError('Incorrect input.')

        # REPLACE PASS ABOVE WITH YOUR CODE
    
    # POSSIBLY DEFINE OTHER METHODS
    def floodfillwUtil(self,screen, x, y, prevC, newC): 
        M=len(screen)
        N=len(screen[0])
        # Base cases 
        if (x < 0 or x >= M or y < 0 or 
            y >= N or screen[x][y] != prevC or 
            screen[x][y] == newC): 
            return
      
        # Replace the color at (x, y) 
        screen[x][y] = newC 
      
        # Recur for north, east, south and west 
        self.floodfillwUtil(screen, x + 1, y, prevC, newC) 
        self.floodfillwUtil(screen, x - 1, y, prevC, newC) 
        self.floodfillwUtil(screen, x, y + 1, prevC, newC) 
        self.floodfillwUtil(screen, x, y - 1, prevC, newC) 



    def floodfillw(self,screen, x, y, newC): 
        prevC = screen[x][y] 
        self.floodfillwUtil(screen, x, y, prevC, newC)
  
# It mainly finds the previous color on (x, y) and  
# calls floodfillwUtil()  
    def floodfilla(self,screen, x, y, newC): 
        prevC = screen[x][y] 
        self.floodfillaUtil(screen, x, y, prevC, newC) 



    #flood fill for accessible areas
    def floodfillaUtil(self,screen, x, y, prevC, newC): 
        M=len(screen)
        N=len(screen[0])
        # Base cases 
        if (x < 0 or x >= M or y < 0 or 
            y >= N or screen[x][y] != prevC or 
            screen[x][y] == newC): 
            return
      
        # Replace the color at (x, y) 
        screen[x][y] = newC 
      
        # Recur for north, east, south and west 
        self.floodfillaUtil(screen, x + 1, y, prevC, newC) 
        self.floodfillaUtil(screen, x - 1, y, prevC, newC) 
        self.floodfillaUtil(screen, x, y + 1, prevC, newC) 
        self.floodfillaUtil(screen, x, y - 1, prevC, newC)

    def culdesac(self,matrix,x,y):
        #print(x,y)
        if str([x,y]) in self.culdesac_intersect.keys():
            if self.culdesac_intersect[str([x,y])] == 1:

                self.xc.insert(0,x)
                self.yc.insert(0,y)
            else:
                self.culdesac_intersect[str([x,y])] -= 1
        coord = []
        M=len(matrix)
        N=len(matrix[0])
        if x > 0:
            if matrix[x-1][y] == 7: coord.append([x-1,y])
        if x < M-1:
            if matrix[x+1][y] == 7: coord.append([x+1,y])
        if y > 0:
            if matrix[x][y+1] == 7: coord.append([x,y+1])
        if y < N-1:
            if matrix[x][y-1] == 7: coord.append([x,y-1])

        if len(coord) == 1:
            matrix[x][y] = 5
            #print(coord)
            self.culdesac(matrix,coord[0][0],coord[0][1])
        elif len(coord) == 0:
            matrix[x][y] = 5
        else:
            self.culdesac_intersect[str([x,y])] = len(coord)

# It mainly finds the previous color on (x, y) and  
# calls floodfillwUtil()  
            
    def analyse(self):
        #r=self.rows
        #c=self.cols
        cpoint=0
        inac=0
        gate=0
        pillar=0
        walls=0
        ac=0
        height=2*(len(self.checkl))-1
        width=2*(len(self.checkl[0]))-1
        #print("height=",height," width=",width)
        nmaze = [[0 for i in range(width)] for j in range(height)]
        #print("new list with 0's",x)
        for x in range(len(self.checkl)):
            for y in range(len(self.checkl[0])):
                if self.checkl[x][y]=='1':
                    nmaze[x*2][y*2]=1
                    nmaze[x*2][y*2+1] = 1
                    nmaze[x*2][y*2+2] = 1

                if self.checkl[x][y] == '2':
                    nmaze[x*2][y*2] = 1
                    nmaze[x*2+1][y*2] = 1
                    nmaze[x*2+2][y*2] = 1

                if self.checkl[x][y] == '3':
                    nmaze[x*2][y*2] = 1
                    nmaze[x*2+1][y*2]=1
                    nmaze[x*2+2][y*2]=1
                    nmaze[x*2][y*2+1]=1
                    nmaze[x*2][y*2+2]=1
        for x in range(0,height):
            for y in range(0,width):
                if x%2 == 0 and y%2==0 and nmaze[x][y]==0:              ###pillar code
                    nmaze[x][y]=2
                    pillar+=1
        #print("Pillars = ",pillar)


        for x in nmaze[-1]:
            if x==0:gate+=1
        for x in nmaze[0]:
            if x==0:gate+=1
        for y in range(0,len(nmaze)):
            if nmaze[y][-1]==0:gate+=1
            if nmaze[y][0]==0:gate+=1
        #print("Gates= ",gate)

## flood fill accessible areas
        xcord=[]
        ycord=[]
        for i in range(height):
            for j in range(width):
                if i==0 or i==height-1 or j == 0 or j==width-1:
                    if nmaze[i][j]==0:
                        xcord.append(i)
                        ycord.append(j)



        # REPLACE PASS ABOVE WITH YOUR CODE
        #for i in nmaze:
        #   print(i)
        # flood fill for walls   wals =9
        for i in range(height):
            for j in range(width):
                if nmaze[i][j]==1:
                    self.floodfillw(nmaze,i,j,9)
                    walls+=1
        #print("walls ",walls)


#flood fill for inaccessible areas ac = 7
        for i in range(len(xcord)):
            x=xcord[i]
            y=ycord[i]
            if nmaze[x][y]==0:
                self.floodfilla(nmaze,x,y,7)
                ac+=1
        #print("ac" , ac)        
#        for i in nmaze:
#            print(i)

        for x in range(1,height,2):
            for y in range(1,width,2):
                if nmaze[x][y]==0:
                    inac+=1
        #print("inaccessible area=",inac)


        self.xc=[]
        self.yc=[]
        for i in range(1,height-1):
            for j in range(1,width-1):
                if nmaze[i][j]==7:
                    count = 0
                    if nmaze[i+1][j]==9:
                        count += 1
                    if nmaze[i-1][j]==9:
                        count += 1
                    if nmaze[i][j+1]==9:
                        count += 1
                    if nmaze[i][j-1]==9:
                        count += 1
                    if count == 3:
                        self.xc.append(i)
                        self.yc.append(j)
                        cpoint+=1


        #print("cpoint=",cpoint)

        self.culdesac_intersect = {}
        while self.xc != []:
            self.culdesac(nmaze,self.xc[-1],self.yc[-1])
            self.xc.pop()
            self.yc.pop()

#        for i in nmaze:
#            print(i)
        display_cord(gate , walls , inac , ac , cpoint)



    
    
    def display(self):
        pass
        # REPLACE PASS ABOVE WITH YOUR CODE
maze=Maze('maze_2.txt')
maze.analyse()